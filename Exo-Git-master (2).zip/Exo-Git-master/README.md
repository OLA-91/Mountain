# Exo-Git 

## Objectif de l'exercice : 

le but de cet exercice est d'avoir un fichier HTML qui contient une petite carte avec la photo de chaque apprenant
Vous disposerez tous du même point de départ et devrez arriver à la fin à un fichier HTML qui contient les modifications de tous les apprenants sur votre ordinateur 

## Déroulé de l'exercice :

commencez par faire un fork de ce repository sur votre compte Github.
Clonez l'exercice sur votre ordinateurApportez vos modifications au fichier index HTML et style Css
Faire un commit puis poussez votre code sur votre repo github
Faites un pull request sur le Repo Master 

## consignes de modification :

 à partir du code HTML de base :
     modifiez l'image pour une photo de vous ou un avatar 
     ajoutez votre nom 
     ajoutez un petit texte ou une citation
     Personalisez votre card 
     les dimensions de la card ne peuvent pas être changées 
     
## consignes de fusion du code : 

pour mettre en commun vos modifications, vous devrez faire un pull request sur le repo master :   
    depuis votre repo personnel, faite un pull request    
    Sur le PC du formateur (connecté sur le repo master) fusionnez le code de votre pull request    
    Vérifiez et corrigez tous conflits de code qui pourraient survenir. 